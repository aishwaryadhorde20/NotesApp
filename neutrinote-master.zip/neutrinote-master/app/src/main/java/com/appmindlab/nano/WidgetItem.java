package com.appmindlab.nano;

/**
 * Created by saelim on 8/5/2015.
 */
public class WidgetItem {
    public long id;
    public String title;
    public String content;

    public WidgetItem(long id, String title, String content) {
        this.id = id;
        this.title = title;
        this.content = content;
    }
}
